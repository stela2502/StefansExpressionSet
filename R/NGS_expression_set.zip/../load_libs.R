# TODO: Add comment
# 
# Author: slang
###############################################################################



#import(affy)  # Affymetrix pre-processing
#import(limma)
library(RSvgDevice)
library(gplots)
library(rgl)
#import(stats)
library(Rsubread)
library(DESeq) 
library("biomaRt")
library(stringr)
library(ggplot2)
library(reshape2)
library(scales)